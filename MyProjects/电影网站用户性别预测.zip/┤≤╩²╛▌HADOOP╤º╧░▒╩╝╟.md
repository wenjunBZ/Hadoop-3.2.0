# HADOOP 大数据学习笔记

## 集群启动顺序参考

[集群启动参考](https://blog.csdn.net/u011414200/article/details/50437356#31-hadoop-%E7%94%9F%E6%80%81%E7%B3%BB%E7%BB%9F%E9%9B%86%E7%BE%A4%E7%9A%84%E5%90%AF%E5%8A%A8%E9%A1%BA%E5%BA%8F%E6%A6%82%E8%A7%88)

## 本人环境  CentOS7.6 Hadoop-3.2.0

```txt
export JAVA_HOME=/usr/local/java/jdk1.8.0_211
export JRE_HOME=$JAVA_HOME/jre

export CLASSPATH=.:$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar

export PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin

#ZOOKEEPER_HOME
export ZOOKEEPER_HOME=/zdata/zookeeper-3.4.14

export PATH=$PATH:$ZOOKEEPER_HOME/bin

#HADOOP_HOME
export HADOOP_HOME=/usr/local/hadoop/hadoop-3.2.0
export PATH=$PATH:$HADOOP_HOME/bin:$HADOOP_HOME/Sbin
```

core-xml.site
```xml

<configuration>
 
<!-- 指定hdfs的nameservice为ns1 -->
 
    <property>
 
        <name>fs.defaultFS</name>
 
        <value>hdfs://ns1/</value>
 
    </property>
 
    <!-- 指定hadoop临时目录 -->
 
    <property>
 
        <name>hadoop.tmp.dir</name>
 
        <value>/hdata/tmp</value>
 
    </property>
 
 
 
    <!-- 指定zookeeper地址 -->
 
    <property>
 
        <name>ha.zookeeper.quorum</name>
 
        <value>h03:2181,h04:2181,h05:2181</value>
 
    </property>
 
</configuration>


```
hdfs-site.xml

```xml

<configuration>
 
    <!--指定hdfs的nameservice为ns1，需要和core-site.xml中的保持一致 -->
 
    <property>
 
        <name>dfs.nameservices</name>
 
        <value>ns1</value>
 
    </property>
 
    <!-- ns1下面有两个NameNode，分别是nn1，nn2 -->
 
    <property>
 
        <name>dfs.ha.namenodes.ns1</name>
 
        <value>nn1,nn2</value>
 
    </property>
 
    <!-- nn1的RPC通信地址 -->
 
    <property>
 
        <name>dfs.namenode.rpc-address.ns1.nn1</name>
 
        <value>h01:9000</value>
 
    </property>
 
    <!-- nn1的http通信地址 -->
 
    <property>
 
        <name>dfs.namenode.http-address.ns1.nn1</name>
 
        <value>h01:50070</value>
 
    </property>
 
    <!-- nn2的RPC通信地址 -->
 
    <property>
 
        <name>dfs.namenode.rpc-address.ns1.nn2</name>
 
        <value>h02:9000</value>
 
    </property>
 
    <!-- nn2的http通信地址 -->
 
    <property>
 
        <name>dfs.namenode.http-address.ns1.nn2</name>
 
        <value>h02:50070</value>
 
    </property>
 
    <!-- 指定NameNode的edits元数据在JournalNode上的存放位置 -->
 
    <property>
 
        <name>dfs.namenode.shared.edits.dir</name>
 
        <value>qjournal://h03:8485;h04:8485;h05:8485/ns1</value>
 
    </property>
 
    <!-- 指定JournalNode在本地磁盘存放数据的位置 -->
 
    <property>
 
        <name>dfs.journalnode.edits.dir</name>
 
        <value>/hdata/jdata</value>
 
    </property>
 
    <!-- 开启NameNode失败自动切换 -->
 
    <property>
 
        <name>dfs.ha.automatic-failover.enabled</name>
 
        <value>true</value>
 
    </property>
 
    <!-- 配置失败自动切换实现方式 -->
 
    <property>
 
        <name>dfs.client.failover.proxy.provider.ns1</name>
 
        <value>org.apache.hadoop.hdfs.server.namenode.ha.ConfiguredFailoverProxyProvider</value>
 
    </property>
 
    <!-- 配置隔离机制方法，多个机制用换行分割，即每个机制暂用一行-->
 
    <property>
 
        <name>dfs.ha.fencing.methods</name>
 
        <value>
 
            sshfence
 
            shell(/bin/true)
 
        </value>
 
    </property>
 
    <!-- 使用sshfence隔离机制时需要ssh免登陆 -->
 
    <property>
 
        <name>dfs.ha.fencing.ssh.private-key-files</name>
 
        <value>/root/.ssh/id_rsa</value>
 
    </property>
 
    <!-- 配置sshfence隔离机制超时时间 -->
 
    <property>
 
        <name>dfs.ha.fencing.ssh.connect-timeout</name>
 
        <value>30000</value>
 
    </property>
 
</configuration>

```
mapred-site.xml

```xml
<configuration>
 
    <!-- 指定mr框架为yarn方式 -->
 
    <property>
 
        <name>mapreduce.framework.name</name>
 
        <value>yarn</value>
 
    </property>
 
</configuration>

```

yarn-site.xml

```xml
<configuration>
 
 
 
<!-- Site specific YARN configuration properties -->
 
<!-- 开启RM高可用 -->
 
    <property>
 
        <name>yarn.resourcemanager.ha.enabled</name>
 
        <value>true</value>
 
    </property>
 
    <!-- 指定RM的cluster id -->
 
    <property>
 
        <name>yarn.resourcemanager.cluster-id</name>
 
        <value>yrc</value>
 
    </property>
 
    <!-- 指定RM的名字 -->

    <property>
 
        <name>yarn.resourcemanager.ha.rm-ids</name>
 
        <value>rm1,rm2</value>
 
    </property>
 
    <!-- 分别指定RM的地址 -->
 
    <property>
 
        <name>yarn.resourcemanager.hostname.rm1</name>
 
        <value>h01</value>
 
    </property>
 
    <property>
 
        <name>yarn.resourcemanager.hostname.rm2</name>
 
        <value>h02</value>
 
    </property>
 
    <!-- 指定zk集群地址 -->
 
    <property>
 
        <name>yarn.resourcemanager.zk-address</name>
 
        <value>h03:2181,h04:2181,h05:2181</value>
 
    </property>
 
    <property>
 
        <name>yarn.nodemanager.aux-services</name>
 
        <value>mapreduce_shuffle</value>
 
    </property>
 
</configuration>

```

## 3. 第三章学习

### 1.1查看hadoop集群的基本信息

#### 1.1.1浏览器方式观察 Hadoop 3.2 中，端口为9870

#### 1.1.2命令行输入

在集群服务器终端，输入相关查询命令 hdfs dfsadmin -report -[cmd]
| 命令|解释|
|-|-|
|hdfs dfsadmin -report     | 输出文件文件系统的基本信息以及相关数据统计|
|hdfs dfsadmin -report  -live | 输出文件系统中在线节点的基本信息以及相关数据统计|
|hdfs dfsadmin -report  -dead | 输出文件系统中失效节点的基本信息以及相关数据统计|
|hdfs dfsadmin -report  -decommissioning | 输出文件系统中停用节点的基本信息以及相关数据统计|

### HDFS 的基本操作

#### 创建新的目录

mkdir
使用方法：hdfs fs -mkdir [paths]
接受路径指定的uri作为参数，创建这些目录。其行为类似于Unix的mkdir -p，它会创建路径中的各级父目录。

示例：

hdfs fs -mkdir /user/hadoop/dir1 /user/hadoop/dir2
hhdfs fs -mkdir hdfs://host1:port1/user/hadoop/dir hdfs://host2:port2/user/hadoop/dir
返回值：

成功返回0，失败返回-1。

#### 上传文件与下载文件

##### 文件上传命令

|命令|解释|
|-|-|
|hdfs dfs -copyFromLocal [-f][-p] [localsrc]..[dst]  | 将文件从本地文件系统复制到HDFS文件系统。主要参数[localsr]为本地文件路径，[src] 为复制的目标路径|
|hdfs  dfs -moveFromLocal [localsrc] [dst]| 将文件从本地文件系统移动到HDFS文件系统。主要参数[localsrc]为本地文件路径，[dst] 为复制的目标路径|
|hdfs dfs -put [localsrc]... [dst]|主要参数[localsrc]为本地文件路径，[dst] 为复制的目标路径 。从本地文件系统中复制单个或者多个源路径到目标文件系统。也支持从标准输入中读取输入写入目标文件系统|

! 注意，使用moveFromLocal 命令时，是移动的意思，本地文件将不存在，相当于剪切

##### 文件下载命令

|命令|解释|
|-|-|
|hdfs dfs -copyToLocal [src]... [localdst]|将文件从HDFS文件系统复制到本地文件系统。主要参数[src]为HDFS文件系统路径，[localdst]为本地文件系统路径|
|hdfs dfs -get [-p] [-ignoreCrc] [src]...[localdst]|获取HDFS文件系统上指定路径的文件到本地文件系统。主要参数[src]为HDFS文件系统路径，[localdst]为本地文件系统路径|

！注意，两种执行方式，执行后HDFS文件系统中，文件仍然存在。不是剪切

##### 查看文件内容

|命令|解释|
|-|-|
|hdfs dfs -cat [src]|查看HDFS文件内容，主要参数[src]指定文件路径|
|hdfs dfs -tail [file]|输出HDFS文件最后1024子节，主要参数[file]指定文件|

##### 删除文件或者目录

|命令|解释|
|-|-|
|hdfs dfs -rm [-r/-R] [src]| 删除HDFS上的文件，主要参数r|R用来递归删除，[src]指定删除文件的路径|
|hdfs dfs -rmdir [dir]|如果删除的是一个目录，则可以用该方法，dir参数为指定目录路径|

#### 提交MapReduce任务给集群

命令格式:
hadoop jar [jarsrc]   [mainclass]   [input src] [output src]

命令包含四个部分
|部分part|解释description|
|-|-|
| hadoop jar | 基础命令行 |
| [jarsrc] | 指的是jar包的路径，包含完整路径|
| [mainclass] | 程序包中的主类名字 |
|  [input src] | HDFS上的输入文件（路径/名字.xx）|
| [outout src] | HDFS上的输出文件目录 |

##### 注意，本人环境为Hadoop3.2.0

使用idea生成jar包。教程参考
`https://www.cnblogs.com/airnew/p/9540982.html`

在添加依赖包时，本人将所有依赖包均添加进入。于是在生成jar包后，上传至集群，并运行，报错：java.lang.SecurityException: Invalid signature file digest for Manifest main attributes
解决方法，参考：

`https://blog.csdn.net/qq_25925973/article/details/53370501`

`https://www.cnblogs.com/fuxinci/p/3356087.html`

【7/9/2019】
参考博文时发现，是本人的包重复添加。目前刚刚入门，未做改动，先按照博文操作

在使用hadoop jar 命令时：
若有mainclass参数，则在主类中，mainclass参数占据一个args的参数位置，位置为argv[0]。inputsrc和output占据argv[1]和[2]

若没有mainclass参数，则在主类中，inputsrc和output占据argv[0]和[1]

## 4. 第四章学习

### 通过源码初认识MapReduce

#### MapReduce原理

1 . Map阶段进行一系列数据处理任务称为Mapper模块
2 . Reduce阶段进行的一系列数据处理任务被称为Reducer阶段

MapRuduce主要成员：
（1） Mapper ：映射器
（2） Mapper助理InputFormat ： 输入文件读取器
（3） Shuffle ：运输队
（4） Shuffle助理Sorter： 排序器
（5） Reducer ： 归约器
（6） Ruducer助理OutputFormat ： 输出结果写入器

##### MapReduce处理流程

（1） 数据分片：将数据分给n个Mapper来处理，每一个Mapper处理一定量的数据，即是Mapper通过数据分片的方式，把数据分发给多个单元来进行处理。这个是分布式计算的第一步。
（2） 数据映射。在数据分片完成后，由Mapper助理InputFormat从文件的输入目录中读取数据，再有Mapper对这些数据记录进行解析，并且重新组织成新的格式。最后由Mapper将自己的处理结果输出，等待Shuffle运输队取走结果。
（3） 数据混洗。由Shuffle运输队把获取的结果按照相同的键（key）进行汇集，再把结果送到Shuffle助理Sort处，由Sort负责对这些结果排序，然后提交给Reducer。
（4） 数据归约。 Reducer收到传输过来的结果后进行汇总与映射工作，得到最终计算结果。最后由Reducer助理OutputFormat把结果输出到指定位置。

## 第五章

Hadoop Java API

这一部分可以查看官网API即可，待补充

## 第六章

基于KNN算法的电影网站用户性别预测
  
根据用户的观影相相似程度，预测用户的性别。

#### KNN算法的实现步骤

1. 计算距离：给定测试对象，计算测试对象与训练集中的每隔对象的距离
2. 寻找邻居：圈定距离最近的K个训练对象，作为测试对象的近邻
3. 寻找分类：根据K个邻居归属的主要类别来作为测试对象的归属类别
   
计算距离的集中方式
* 欧式距离
* 曼哈顿距离
* 闵可夫斯基距离
  
### 案例过程

#### 数据预处理

##### 1.获取数据

数据格式见data

##### 2.数据变换

根据原始数据的样本，找到数据的特征，并表示出来

##### 3.数据清洗

异常值和缺失值的处理

* 缺失值的处理：删除记录和数据插补

常见数据插补方法：

* 均值/中位数/众数插补
* 固定值插补
* 最近邻插补
* 回归方法
* 插值方法

* 异常值的处理方法：
  *  删除含有异常值的记录
  *  视为缺失值来补充
  *  平均修正

##### 4. 划分数据集

将数据划分为训练集，测试机，验证集

#### 算法实现

根据KNN算法的基本思想，对数据集进行测试

#### 模型验证

评价模型的ROC曲线，寻找最优K值

数据和代码见文件夹

